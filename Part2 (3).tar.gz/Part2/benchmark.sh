#!/bin/bash

#SBATCH --job-name=prophet-benchmark

#SBATCH --output=benchmark_output.log

#SBATCH --error=benchmark_error.log

#SBATCH --ntasks=1

#SBATCH --cpus-per-task=10

#SBATCH --time=00:20:00

#SBATCH --mem=8G



# Load Python

module load python/3.11.4



# (Optional) Use a virtual environment if needed

# source activate my_env



# Run benchmark

python real_forecast_benchmark.py

