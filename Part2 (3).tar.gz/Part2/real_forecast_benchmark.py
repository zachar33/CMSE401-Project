import time

import yfinance as yf

from prophet import Prophet

from concurrent.futures import ProcessPoolExecutor

import matplotlib.pyplot as plt



# List of tickers (use 10+ for clearer runtime difference)

tickers = ['AAPL', 'MSFT', 'GOOGL', 'NVDA', 'META',

           'TSLA', 'AMZN', 'NFLX', 'INTC', 'ORCL']



def run_real_forecast(symbol):

    try:

        df = yf.Ticker(symbol).history(period="10y").reset_index()

        df = df[['Date', 'Close']].rename(columns={'Date': 'ds', 'Close': 'y'})

        df['ds'] = df['ds'].dt.tz_localize(None)

        

        model = Prophet()

        model.fit(df)

        future = model.make_future_dataframe(periods=30)

        forecast = model.predict(future)

        return symbol, forecast

    except Exception as e:

        return symbol, f"Error: {e}"



# Sequential execution

start_seq = time.time()

sequential_results = [run_real_forecast(t) for t in tickers]

end_seq = time.time()

seq_time = end_seq - start_seq

print(f"Sequential runtime: {seq_time:.2f} seconds")



# Parallel execution

start_par = time.time()

with ProcessPoolExecutor() as executor:

    parallel_results = list(executor.map(run_real_forecast, tickers))

end_par = time.time()

par_time = end_par - start_par

print(f"Parallel runtime: {par_time:.2f} seconds")



# Plotting

labels = ['Sequential', 'Parallel']

times = [seq_time, par_time]



plt.figure(figsize=(6, 4))

plt.bar(labels, times, color=['red', 'green'])

plt.ylabel('Total Runtime (seconds)')

plt.title(f'Prophet Forecasting: Parallel vs Sequential ({len(tickers)} Models)')

plt.grid(axis='y')

plt.tight_layout()

plt.show()



# Optional speedup calculation

speedup = seq_time / par_time

print(f"Speedup: {speedup:.2f}×")

